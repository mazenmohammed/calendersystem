<?php

echo "<h3> welcom</h3> ";  
?>

</br><a href='signuppage.php'>signup</a></br>
<a href='signin.php'>signin</a>