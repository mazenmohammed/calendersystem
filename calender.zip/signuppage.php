
<form action="" method="get">
name <input type="text" name="name"><br>
password<input type="password" name="password"><br>
department<select name="department" id="ID">
  <option value="sales">sales</option>
  <option value="tech">tech</option>
  <option value="finance">finance</option>
  
</select>
<input type="submit" name=' submit'>
</form>

<?php
$servername="localhost";
$username="mazenproject";
$password="123";
$db="meeting";

$con=mysqli_connect($servername,$username,$password,$db);
if(isset($_GET['submit'])){
$name=$_GET['name'];
$password=$_GET['password'];
$department=$_GET['department'];

$sql="insert into employe(name,password,department) values('$name','$password', '$department')" ;

mysqli_query($con,$sql);
header("location:home.php");
}


?> 