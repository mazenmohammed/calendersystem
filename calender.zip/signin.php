<form action="calenderinterface.php" method="post">
name <input type="text" name="name"><br>
password<input type="password" name="password"><br>
<input type="submit" name=' submit'>
</form>

<?php
$servername="localhost";
$username="mazenproject";
$password="123";
$db="user";

$con=mysqli_connect($servername,$username,$password,$db);
if(isset($_POST['submit'])){
$name=$_POST['name'];
$password=$_POST['password'];

$sql="select * from employe where  name='$name' and password='$password' " ;

$result= mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result))
{
	header("location:calenderinerface.php");
}

echo "wrong name or password";


}

?> 