<!DOCTYPE html> 
<html>
<table border="5">
  <tr>
  <th> The Day </th>
    <th>Saturday</th>
    <th>Sunday </th>
    <th>Monday</th>
	<th>Tuesday</th>
	<th>Wednesday</th>
	<th>Thursday</th>
	<th>Friday 	</th>
  </tr>
  <tr>
  <td> Meetings </td>
    <td  </td>
    <td>   </td>
    <td>   </td>
	<td>  </td>
    <td>  </td>
    <td>   </td>
	<td>   </td>
    
  </tr>
   <tr>
  <td> Events </td>
    <td  </td>
    <td>   </td>
    <td>   </td>
	<td>  </td>
    <td>  </td>
    <td>   </td>
	<td>   </td>
    
  </tr>
  <form action="" method="POST"> 
Eventname<input type="text" name="eventname">
<button type="submit" name="submit">addevent</button>
  </form>
<?php
$servername="localhost";
$username="mazenproject";
$password="123";
$db="meeting";

$con=mysqli_connect($servername,$username,$password,$db);

if(isset($_POST['submit'])){
$eventname=$_POST['eventname'];

$sql="insert into events(eventname) values('$eventname')" ;

mysqli_query($con,$sql);

$sql = "select eventname from events";

$result=mysqli_query($con,$sql);
$resultcheck= mysqli_num_rows($result);
if($resultcheck >  0){
	while($row=mysqli_fetch_assoc($result)){

		echo "<td>".$row['eventname']."</td>"; 
		
	}
}
}
?>
 
  
  <tr>
 
  </tr>
</table>


</html >
<!DOCTYPE html> 
<html>
<table border="5">
  <tr>
  <th> The Day</th>
   
  </tr>
  <tr>
  <td> Meetings&time </td>
 
    
	<?php  $servername="localhost";
$username="mazenproject";
$password="123";
$db="meeting";

$con=mysqli_connect($servername,$username,$password,$db);

 
$sql = "select *from meetings ";

$result=mysqli_query($con,$sql);
$resultcheck= mysqli_num_rows($result);
if($resultcheck >  0){
	while($row=mysqli_fetch_assoc($result)){

		echo "<td>".$row['Tittle']."</td>"; 
		echo "<br>"."<td>".$row['starttime']."</td>";
	}
}
?>
    
  
  
  <form action="meetings.php" method="post"> 
  To Add Meeting Press  <a href="meetings.php"> here</a>

 
 </button>
  </form>
  
  
</table>


</html >
