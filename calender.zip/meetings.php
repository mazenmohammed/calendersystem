<?php
$servername="localhost";
$username="mazenproject";
$password="123";
$db="meeting";

$con=mysqli_connect($servername,$username,$password,$db);

// Check connection
if ($con) {
  
}


?>
<html> 

<h2> Add Meeting  </h2><br> <br> 
<form Meeting="/Meeting_page.php" method="post"> 
<label for="Tittle"> Tittle:</label>
<input type="text" id="Tittle" name="Tittle" ><br> 

<label for="Description"> Description:</label>
<input type="text" id="Description" name="Description" ><br> 

<label> todayDate:</label>
<input type="date" id="todayDate" name="todayDate"><br> 

<label for="starttime"> starttime:</label>
<input type="text" id="todayTime" name="starttime"><br> 
<label for="endtime"> endtime:</label>
<input type="text" id="todayTime" name="endtime"><br> 

<label for="Participants"> Participants:</label>
<input type="text" id="Participants" name="Participants"><br> 
<label for="room"> rooms:</label>
<select name="room" id="room">

<?php

$sql="select roomid from room";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result))
{
	$roomid=$row['roomid'];
	echo "<option value='$roomid'>$roomid</option>;";
	
}
if(isset($_POST['submit'])){
$Tittle=$_POST['Tittle'];
$Description=$_POST['Description'];
$todayDate=$_POST['todayDate'];
$starttime=$_POST['starttime'];
$endtime=$_POST['endtime'];
$Participants=$_POST['Participants'];
$sql = "INSERT INTO meetings (Tittle , Description , todayDate , starttime,endtime ,Participants)
VALUES ('$Tittle','$Description' , '$todayDate' , '$starttime','$endtime', '$Participants')";


$result=mysqli_query($con,$sql);
if($result){
	
	echo "INSERTION DONE";
}else
{echo "not inserted".mysql_error($con);}

}
if($starttime>$endtime)
{
	echo "you can't set endtime grater than starttime";
}
?>

 <input type="submit" value="Submit" name="submit">
</form>

</html>