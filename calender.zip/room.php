
<form action="" method="post">
capacity </b> <input type="text" name="roomcapa">
<input type="submit">
</form>

<?php
$servername="localhost";
$username="mazenproject";
$password="123";
$db="user"; 


$con=mysqli_connect($servername,$username,$password,$db);
for($i=0;$i<50;$i++){
	
$sql="insert into room(capacity) values('10')" ;
  mysqli_query($con,$sql);
}
	






}











