
<form action="" method="get">
name <input type="text" name="name"><br>
password<input type="password" name="password"><br>
<input type="submit">
</form>

<?php
$servername="localhost";
$username="mazenproject";
$password="123";
$db="user";

$con=mysqli_connect($servername,$username,$password,$db);
if(isset($_GET['submit'])){
$name=$_GET['name'];
$password=$_GET['password'];



$sql="insert into employe(name,password) values('$name','$password')" ;

mysqli_query($con,$sql);
}


?> 